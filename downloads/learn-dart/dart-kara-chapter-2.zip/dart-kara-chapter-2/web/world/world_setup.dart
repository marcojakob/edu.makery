part of world;

/**
 * A WorldSetup contains information about the positions of the actors in the
 * world. A WorldSetup is immutable, i.e. after initialization it should not be
 * changed. An immutable WorldSetup is easier to work with because we can be sure
 * that there will not be any side-effects if we make changes to any actors. And
 * we can always restore the initial WorldSetup.
 * 
 * The actor positions are described with the following signs:
 * * Kara: @
 * * Tree: #
 * * Leaf: .
 * * Mushroom: $
 * * Mushroom on Leaf: *
 * * Kara on Leaf: +
 * * Empty Field: Space
 */
class WorldSetup {
  static const String UNDEFINED = '?';
  static const String EMPTY = ' ';
  static const String KARA = '@';
  static const String TREE = '#';
  static const String LEAF = '.';
  static const String MUSHROOM = r'$'; // r means raw String (dollar sign is treated as a normal String)
  static const String MUSHROOM_LEAF = '*'; // Mushroom on a leaf
  static const String KARA_LEAF = '+'; // Kara on a leaf
  
  /**
   * The title of the [WorldSetup].
   */
  final String title;
  
  /**
   * The world width.
   */
  final int width;
  
  /**
   * The world height.
   */
  final int height;
  
  /**
   * The initial world state containing all actor positions.
   */
  final WorldState worldState;
  
  /**
   * Creates a [WorldSetup] with specified [title], [width] and [height].
   * 
   * [actorsString] is a multi-line String with actor signs (see class 
   * description).
   */
  factory WorldSetup(String title, int width, int height, String actorsString, 
      {karaDirection: DIRECTION_RIGHT}) {
    // Actor positions: Each list entry is a line (y-position) and the position 
    // of the character in the String is the column (x-position). 
    List<String> actorPositions = actorsString.split('\n');
    
    List<Actor> actors = new List<Actor>();
    int karaX;
    int karaY;
    
    for (int y = 0; y < actorPositions.length && y < height; y++) {
      for (int x = 0; x < actorPositions[y].length && x < width; x++) {
        switch (actorPositions[y][x]) {
          case WorldSetup.KARA:
            karaX = x;
            karaY = y;
            break;
          case WorldSetup.TREE:
            actors.add(new Tree(x, y));
            break;
          case WorldSetup.LEAF:
            actors.add(new Leaf(x, y));
            break;
          case WorldSetup.MUSHROOM:
            actors.add(new Mushroom(x, y));
            break;
          case WorldSetup.MUSHROOM_LEAF:
            actors.add(new Mushroom(x, y));
            actors.add(new Leaf(x, y));
            break;
          case WorldSetup.KARA_LEAF:
            karaX = x;
            karaY = y;
            actors.add(new Leaf(x, y));
            break;
        }
      }
    }
    
    assert(karaX != null && karaY != null); // The world must contain a valid position for Kara!
    
    WorldState state = new WorldState(actors, karaX, karaY, karaDirection);
    return new WorldSetup._internal(title, width, height, state);
  }
  
  /**
   * Creates a [WorldSetup] with specified [title], [width] and [height] and
   * [worldState].
   */
  WorldSetup._internal(this.title, this.width, this.height, this.worldState);
}