library actors;

import '../world/world.dart';

part 'kara.dart';
part 'leaf.dart';
part 'mushroom.dart';
part 'tree.dart';


const int DIRECTION_RIGHT = 0;
const int DIRECTION_DOWN = 90;
const int DIRECTION_LEFT = 180;
const int DIRECTION_UP = 270;

/**
 * Superklasse fuer alle [Actor]s.
 */
abstract class Actor {
  /// The horizontal position.
  int x;
  
  /// The vertical position.
  int y;
  
  /// The CSS class to display the current actor image.
  String get imageClass;
  
  Actor(this.x, this.y);
  
  /// Creates a clone 
  Actor clone();
  
  /// Moves the actor in the specified [direction].
  void _move(int direction) {
    switch (direction) {
      case DIRECTION_RIGHT:
        x = (x + 1) % world.worldSetup.width;
        break;
      case DIRECTION_DOWN:
        y = (y + 1) % world.worldSetup.height;
        break;
      case DIRECTION_LEFT:
        x = (x - 1) % world.worldSetup.width;
        break;
      case DIRECTION_UP:
        y = (y - 1) % world.worldSetup.height;
        break;
    }    
  }
}
