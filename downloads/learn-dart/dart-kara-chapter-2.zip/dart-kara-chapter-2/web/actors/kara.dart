part of actors;

/**
 * Diese Klasse ist die Oberklasse fuer alle Karas und enthaelt die
 * Grundfunktionen von Kara. Programme sollten nur in den Unterklassen wie
 * MyKara geschrieben werden.
 */
abstract class Kara extends Actor {
  int direction = DIRECTION_RIGHT;
  
  Kara() : super(0, 0);
  
  /**
   * In der Methode 'act()' koennen die Befehle fuer Kara programmiert werden.
   */
  void act();
  
  /**
   * Kara macht einen Schritt in die aktuelle Richtung.
   */
  void move() {
    // Check for a tree.
    if (treeFront()) {
      world.render();
      throw new KaraException('Kara kann sich nicht bewegen wegen einem Baum!');
    }
    
    // Check for a mushroom.
    Mushroom mushroomFront = world.getActorsInFront(x, y, direction)
        .firstWhere((Actor a) => a is Mushroom, orElse: () => null);
    
    if (mushroomFront != null) {
      // Check if the mushroom could be pushed to the next field.
      if (!world.getActorsInFront(x, y, direction, 2)
          .any((Actor a) => a is Tree || a is Mushroom)) {
        // Push the mushroom.
        mushroomFront._move(direction);
      } else {
        // Could not push the mushroom.
        world.render();
        throw new KaraException('Kara kann sich nicht bewegen, da er den Pilz nicht schieben kann!');
      }
    }
    
    // Kara can move.
    _move(direction);
    world.render();
  }
  
  /**
   * Kara dreht sich um 90° nach links.
   */
  void turnLeft() {
    direction = (direction - 90) % 360;
    world.render();
  }
  
  /**
   * Kara dreht sich um 90° nach rechts.
   */
  void turnRight() {
    direction = (direction + 90) % 360;
    world.render();
  }
  
  /**
   * Kara legt ein neues Kleeblatt an die Position, auf der er sich befindet.
   */
  void putLeaf() {
    if (!onLeaf()) {
      Leaf leaf = new Leaf(x, y);
      world.actors.add(leaf);
      world.render();
    } else {
      world.render();
      throw new KaraException('Kara kann kein Kleeblatt auf ein Feld legen, auf dem schon eines ist!');
    }
  }
  
  /**
   * Kara entfernt ein unter ihm liegendes Kleeblatt.
   */
  void removeLeaf() {
    Leaf leaf = world.getActorsAt(x, y).firstWhere((Actor a) => a is Leaf, orElse: () => null);
    if (leaf != null) {
      world.actors.remove(leaf);
      world.render();
    } else {
      world.render();
      throw new KaraException('Kara kann hier kein Blatt auflesen!');
    }
  }
  
  /**
   * Kara schaut nach, ob er sich auf einem Kleeblatt befindet. Gibt true 
   * zurueck, wenn er auf einem Kleeblatt ist, sonst false.
   */
  bool onLeaf() {
    return world.getActorsAt(x, y).any((Actor a) => a is Leaf);
  }
  
  /**
   * Kara schaut nach, ob sich ein Baum vor ihm befindet. Gibt true zurueck,
   * wenn er vor einem Baum steht, sonst false.
   */
  bool treeFront() {
    return world.getActorsInFront(x, y, direction).any((Actor a) => a is Tree);
  }
  
  /**
   * Kara schaut nach, ob sich ein Baum links von ihm befindet. Gibt true 
   * zurueck, wenn links von ihm ein Baum steht, sonst false.
   */
  bool treeLeft() {
    return world.getActorsInFront(x, y, (direction - 90) % 360).any((Actor a) => a is Tree);
  }
  
  /**
   * Kara schaut nach, ob sich ein Baum rechts von ihm befindet. Gibt true 
   * zurueck, wenn rechts von ihm ein Baum steht, sonst false.
   */
  bool treeRight() {
    return world.getActorsInFront(x, y, (direction + 90) % 360).any((Actor a) => a is Tree);
  }
  
  /**
   * Kara schaut nach, ob er einen Pilz vor sich hat. Gibt true zurueck, wenn 
   * vor ihm ein Pilz steht, sonst false.
   */
  bool mushroomFront() {
    return world.getActorsInFront(x, y, direction).any((Actor a) => a is Mushroom);
  }
  
  Actor clone() {
    throw new Exception('No clone of Actor possible!');
  }
  
  String get imageClass => imageClassWithDirection(direction);
  
  /**
   * Appends a direction identifier to the image class and returns it.
   */
  static String imageClassWithDirection(int direction) {
    switch (direction) {
      case DIRECTION_RIGHT:
        return 'kara-right';
      case DIRECTION_DOWN:
        return 'kara-down';
      case DIRECTION_LEFT:
        return 'kara-left';
      case DIRECTION_UP:
        return 'kara-up';
      default: 
        return 'kara';
    }
  }
}
