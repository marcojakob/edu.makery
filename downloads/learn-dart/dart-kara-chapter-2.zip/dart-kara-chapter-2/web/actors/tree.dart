part of actors;

/**
 * Ein Baum ist ein Hindernis fuer Kara. Kara kann weder durch Baeume hindurch
 * gehen noch kann er sie schieben.
 */
class Tree extends Actor {
  Tree(int x, int y) : super(x, y);
  
  String get imageClass => 'tree';

  Actor clone() {
    return new Tree(x, y);
  }
}
