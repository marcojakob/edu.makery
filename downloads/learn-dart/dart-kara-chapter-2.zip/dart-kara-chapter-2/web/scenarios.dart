part of kara;

/*
 * Jedes Szenario enthaelt Informationen ueber die Groesse der Welt und die 
 * Positionen der Blaetter, Baueme, Pilze und von Kara. 
 * 
 * Die Positionen werden mit folgenden Zeichen beschrieben:
 * Kara: @
 * Tree: #
 * Leaf: .
 * Mushroom: $
 * Mushroom on Leaf: *
 * Kara on Leaf: +
 * Empty Field: Space
 */

WorldSetup scenario04a() {
  return new WorldSetup('04a Around Tree II', 10, 2, r'''

@ # #  #.
  ''');
}

WorldSetup scenario04b() {
  return new WorldSetup('04b Around Tree II', 10, 2, r'''

 @# # #.
  ''');
}

WorldSetup scenario04c() {
  return new WorldSetup('04c Around Tree II', 10, 2, r'''

@  # # #.#
  ''');
}

WorldSetup scenario05a() {
  return new WorldSetup('05a Afraid Of Tunnel', 9, 3, r'''
   #####
@
     ####
  ''');
}

WorldSetup scenario05b() {
  return new WorldSetup('05b Afraid Of Tunnel', 9, 3, r'''
   #####
@
   ######
  ''');
}

WorldSetup scenario05c() {
  return new WorldSetup('05c Afraid Of Tunnel', 9, 3, r'''
   ######
   @
   ######
  ''');
}

WorldSetup scenario06() {
  return new WorldSetup('06 Leaf At Tree', 9, 3, r'''
  #   ##
@
    # #
  ''');
}

WorldSetup scenario07() {
  return new WorldSetup('07 Put Leaf Track', 9, 3, r'''

@ ..  . #
  ''');
}

WorldSetup scenario08a() {
  return new WorldSetup('08a Kara As Guard', 9, 9, r'''

    ####
   #...#
  #....#
@#.....#
  #..##
 #..#
  ###
  ''', karaDirection: DIRECTION_UP);
}

WorldSetup scenario08b() {
  return new WorldSetup('08a Kara As Guard', 9, 9, r'''

 #######
 #.....#
 #.###.#
 #.# #.#
 #.# #.#
 #.# #.#
 ### ###
   @
  ''', karaDirection: DIRECTION_LEFT);
}