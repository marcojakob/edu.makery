library kara;

import 'world/world.dart';
import 'actors/actors.dart';

part 'scenarios.dart';

/**
 * MyKara ist eine Unterklasse von Kara. Sie erbt damit alle Methoden der 
 * Klasse Kara:
 * 
 * Aktionen: move(), turnLeft(), turnRight(), putLeaf(), removeLeaf()
 * Sensoren: onLeaf(), treeFront(), treeLeft(), treeRight(), mushroomFront()
 */
class MyKara extends Kara {
  
  /**
   * In der Methode 'act()' koennen die Befehle fuer Kara programmiert werden.
   */
  void act() {
    // Wiederholen, solange nicht auf einem Blatt.
    while (!onLeaf()) {
      
      move();
      
    }
  }
  
  void goAroundTree() {
    turnLeft();
    move();
    turnRight();
    move();
    move();
    turnRight();
    move();
    turnLeft();
  }
}

/**
 * Die main-Methode ist der Start des Programms, wo die Kara Welt geladen wird.
 */
main() {
  start(scenario04a(), new MyKara());
}