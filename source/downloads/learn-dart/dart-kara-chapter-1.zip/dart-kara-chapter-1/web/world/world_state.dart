part of world;

/**
 * The [WorldState] contains the position of all actors. It represents the 
 * world state in a specific moment.
 */
class WorldState {
  /// A list of all actors except kara (leafs, mushrooms and trees).
  final List<Actor> actors;
  
  /// Kara's x-position.
  final int karaX;
  /// Kara's y-position.
  final int karaY;
  /// Kara's direction.
  final int karaDirection;
  
  /**
   * Creates a new WorldState by cloning all [actors] and storing the kara 
   * information.
   */
  WorldState(List<Actor> actors, this.karaX, this.karaY, this.karaDirection) : 
    this.actors = new List() {
    
    for (Actor actor in actors) {
      this.actors.add(actor.clone());
    }
  }
  
  /**
   * Displays this state in the browser.
   */
  void show() {
    // Remove all actor classes.
    queryAll('.field').classes.removeWhere((cssClass) => cssClass != 'field');
    
    // Add immutable actor classes.
    for (Actor actor in actors) {
      _addActor(actor.x, actor.y, actor.imageClass);      
    }
    
    // Add Kara.
    _addActor(karaX, karaY, Kara.imageClassWithDirection(karaDirection));
  }
  
  /**
   * Adds the actor image at position [x], [y].
   */
  void _addActor(int x, int y, String imageClass) {
    DivElement field = query('.field[x="${x}"][y="${y}"]');
    field.classes.add(imageClass);
  }
}