library world;

import 'dart:html';
import 'dart:async';
import 'dart:collection';
import 'dart:math' as math;
import '../actors/actors.dart';

part 'world_setup.dart';
part 'world_state.dart';

const int _MAX_CELL_SIZE = 28; // 27px + 1px for the border.

/// The global World instance containing the world state.
World world;

Duration _speed = new Duration(milliseconds: 800);
KaraException _exception;

/**
 * Initializes the world with [worldSetup] and shows it.
 * [kara] is the class where the behaviour of Kara is programmed in.
 */
void start(WorldSetup worldSetup, Kara kara) {
  world = new World(worldSetup, kara);
  _exception = null;
  
  try {
    kara.act();
  } on KaraException catch(ex) {
    // Save exception to be displayed when the world state queue is empty.
    _exception = ex;
  }
}

/**
 * The [World] class sets up a grid for actors. It draws all actors and 
 * controls their state.
 */
class World {
  /// The initial world setup (will not be changed).
  final WorldSetup worldSetup;
  
  /// A reference to the Kara instance.
  final Kara kara;
  
  /// A list of all actors except Kara (leafs, mushrooms and trees).
  final List<Actor> actors = new List<Actor>();
  
  /// A Queue of world states waiting to be rendered.
  final Queue<WorldState> _renderQueue = new Queue<WorldState>();
  
  /// The timer for rendering.
  Timer _renderTimer;
  
  /**
   * Creates a new [World].
   */
  World(this.worldSetup, this.kara) {
    // Set initial state according to world setup.
    actors.addAll(worldSetup.worldState.actors);
    kara.x = worldSetup.worldState.karaX;
    kara.y = worldSetup.worldState.karaY;
    kara.direction = worldSetup.worldState.karaDirection;
    
    _initWorld();
    _initSpeedSlider();
    render();
  }
  
  /**
   * Creates an empty world for Kara with the number of horizontal and vertical
   * cells defined in [worldSetup].
   */
  void _initWorld() {
    Element karaWorld = query('#kara-world');
    
    // Add title.
    karaWorld.children.add(new Element.p()..text = worldSetup.title);
    
    // Ensures the cells don't grow bigger than the images.
    karaWorld.style.maxWidth = '${worldSetup.width * _MAX_CELL_SIZE}px';
    
    // Create div to make world resizable.
    Element karaWorldResize = new Element.div()
    ..id = 'kara-world-resize';
    // padding-top sets the aspect ratio used for resizing.
    karaWorldResize.style.paddingTop = '${worldSetup.height / worldSetup.width * 100}%';
    karaWorld.children.add(karaWorldResize);
    
    // Create div container for fields.
    Element karaWorldInner = new Element.div()
    ..id = 'kara-world-inner';
    karaWorldResize.children.add(karaWorldInner);
    
    // Add field div elements.
    double fieldWidth = 100 / worldSetup.width;
    double fieldHeight = 100 / worldSetup.height;
    
    for (int y = 0; y < worldSetup.height; y++) {
      for (int x = 0; x < worldSetup.width; x++) {
        DivElement field = new Element.div()
        ..classes.add('field')
        ..attributes['x'] = x.toString()
        ..attributes['y'] = y.toString()
        ..style.width = '${fieldWidth}%'
        ..style.height = '${fieldHeight}%';
        karaWorldInner.children.add(field);
      }
    }
  }
  
  /**
   * Initializes the slider to change the speed.
   */
  void _initSpeedSlider() {
    Element karaWorld = query('#kara-world');
    
    InputElement slider = new Element.tag('input');
    slider..id = 'speed-slider'
        ..type = 'range'
        ..min = '0'
        ..max = '1000'
        ..value = '${1000 - _logValueToSlider(_speed.inMilliseconds)}'
        ..step = '1'
        ..onChange.listen((_) {
          int sliderValue = 1000 - math.max(0, math.min(1000, int.parse(slider.value)));
          int ms = _logSliderToValue(sliderValue);
          
          _speed = new Duration(milliseconds: ms);
          
          // Restart render timer with new speed.
          _startRenderTimer();
        });
    
    karaWorld.children.add(slider);
  }
  
  int _logSliderToValue(int sliderValue) {
    int minSlider = 0;
    int maxSlider = 1000;
    
    double minValue = math.log(1);
    double maxValue = math.log(2000);
    
    // Calculate adjustment factor.
    double scale = (maxValue - minValue) / (maxSlider - minSlider);
    
    return math.exp(minValue + scale * (sliderValue - minSlider)).round();
  }
  
  int _logValueToSlider(int value) {
    int minSlider = 0;
    int maxSlider = 1000;
    
    double minValue = math.log(1);
    double maxValue = math.log(2000);
    
    // Calculate adjustment factor.
    double scale = (maxValue - minValue) / (maxSlider - minSlider);
    
    return ((math.log(value) - minValue) / scale + minSlider).round();
  }
  
  /**
   * Renders the current world state with [actors] and [kara]. 
   * 
   * Note: The rendering is not done immediately. The current world state is 
   * added to a queue where itmes are rendered with a fixed delay between them.
   */
  void render() {
    // Add the current world state at the end of the queue.
    _renderQueue.add(new WorldState(actors, kara.x, kara.y, kara.direction));
    
    if (_renderQueue.length > 100000) {
      throw new KaraException('Ihr Programm dauert zu lange oder beendet gar nicht!');
    }
    
    // Start timer if it is not already running.
    if (_renderTimer == null || !_renderTimer.isActive) {
      _startRenderTimer();
    }
  }
  
  /**
   * Creates and starts the render timer. If already running, the current timer
   * is canceled and restarted.
   */
  Timer _startRenderTimer() {
    // Cancel timer if it is already running.
    if (_renderTimer != null && _renderTimer.isActive) {
      _renderTimer.cancel();
    }

    Duration currentTimerSpeed = _speed;
    _renderTimer = new Timer.periodic(_speed, (Timer t) {
      
      if (_renderQueue.isNotEmpty) {
        // Get next world state.
        WorldState state = _renderQueue.removeFirst();
        state.show();
        
      } else {
        // Queue is empty -> cancel.
        t.cancel();
        
        // Display exception if there was one during execution of the program.
        if (_exception != null) {
          window.alert(_exception.message);
        }
      }
    });
  }
  
  /**
   * Returns a list of actors at the specified location.
   */
  Iterable<Actor> getActorsAt(int x, int y) {
    return actors.where((Actor actor) => actor.x == x && actor.y == y);
  }
  
  /**
   * Returns a list of actors that are a number of [steps] away from [x], [y] 
   * in the specified [direction].
   */
  Iterable<Actor> getActorsInFront(int x, int y, int direction, [int steps = 1]) {
    switch (direction) {
      case DIRECTION_RIGHT: 
        x = (x + steps) % worldSetup.width;
        break;
      case DIRECTION_DOWN: 
        y = (y + steps) % worldSetup.height;
        break;
      case DIRECTION_LEFT: 
        x = (x - steps) % worldSetup.width;
        break;
      case DIRECTION_UP: 
        y = (y - steps) % worldSetup.height;
        break;
    }
    
    return getActorsAt(x, y);
  }
}

/**
 * Exception for errors created by the user.
 */
class KaraException implements Exception {
  
  /**
   * A message describing the kara exception.
   */
  final String message;

  /**
   * Creates a new KaraException with an optional error [message].
   */
  const KaraException([this.message = ""]);

  String toString() => "Kara Fehler: $message";
}

