part of actors;

/**
 * Ein Blatt kann von Kara gelegt und wieder aufgelesen werden.
 */
class Leaf extends Actor {
  Leaf(int x, int y) : super(x, y);

  String get imageClass => 'leaf';
  
  Actor clone() {
    return new Leaf(x, y);
  }
}
