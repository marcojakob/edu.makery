part of actors;

/**
 * Ein Pilz kann von Kara gestossen werden falls nichts hinter dem Pilz steht.
 */
class Mushroom extends Actor {
  Mushroom(int x, int y) : super(x, y);
  
  String get imageClass => 'mushroom';

  Actor clone() {
    return new Mushroom(x, y);
  }
}
