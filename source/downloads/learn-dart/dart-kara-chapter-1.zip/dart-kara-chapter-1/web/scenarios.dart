part of kara;

/*
 * Jedes Szenario enthaelt Informationen ueber die Groesse der Welt und die 
 * Positionen der Blaetter, Baueme, Pilze und von Kara. 
 * 
 * Die Positionen werden mit folgenden Zeichen beschrieben:
 * Kara: @
 * Tree: #
 * Leaf: .
 * Mushroom: $
 * Mushroom on Leaf: *
 * Kara on Leaf: +
 * Empty Field: Space
 */

WorldSetup scenario01() {
  return new WorldSetup('01 Putting Leaf', 10, 10, r'''





 @
''');
}

WorldSetup scenario02() {
  return new WorldSetup('02 Around Tree', 10, 10, r'''




@ # #  #.
  ''');
}

WorldSetup scenario03() {
  return new WorldSetup('03 Around Tree With Method', 10, 10, r'''




@ # #  #.
  ''');
}