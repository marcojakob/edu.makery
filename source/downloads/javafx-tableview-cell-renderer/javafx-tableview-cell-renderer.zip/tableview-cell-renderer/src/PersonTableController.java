import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.util.Callback;

public class PersonTableController {
	@FXML
	private TableView<Person> personTable;
	@FXML
	private TableColumn<Person, String> firstNameColumn;
	@FXML
	private TableColumn<Person, String> lastNameColumn;
	@FXML
	private TableColumn<Person, Calendar> birthdayColumn;
	
	private ObservableList<Person> personData = FXCollections.observableArrayList();
	
	/**
	 * The constructor. The constructor is called before the initialize()
	 * method.
	 */
	public PersonTableController() {
		// Add some sample data to the master data
		Calendar c1 = Calendar.getInstance();
		c1.set(2012, 2, 22);
		Calendar c2 = Calendar.getInstance();
		c2.set(2012, 4, 2);
		Calendar c3 = Calendar.getInstance();
		c3.set(2011, 2, 22);
		Calendar c4 = Calendar.getInstance();
		c4.set(2012, 5, 13);
		
		personData.add(new Person("Hans", "Muster", c1));
		personData.add(new Person("Ruth", "Mueller", c2));
		personData.add(new Person("Heinz", "Kurz", c3));
		personData.add(new Person("Cornelia", "Meier", c4));
	}

	/**
	 * Initializes the controller class. This method is automatically called
	 * after the fxml file has been loaded.
	 */
	@FXML
	private void initialize() {
		// Initialize the person table
		firstNameColumn.setCellValueFactory(
				new PropertyValueFactory<Person, String>("firstName"));
		lastNameColumn.setCellValueFactory(
				new PropertyValueFactory<Person, String>("lastName"));
		birthdayColumn.setCellValueFactory(
				new PropertyValueFactory<Person, Calendar>("birthday"));
		
		birthdayColumn.setCellFactory(new Callback<TableColumn<Person, Calendar>, TableCell<Person, Calendar>>() {
			@Override
			public TableCell<Person, Calendar> call(TableColumn<Person, Calendar> param) {
				return new TableCell<Person, Calendar>() {
					@Override
					protected void updateItem(Calendar item, boolean empty) {
						super.updateItem(item, empty);
						
		                if (!empty) {
		                	setText(format(item));
		                	
		                    if (item.get(Calendar.YEAR) == 2011) {
		                    	setTextFill(Color.CHOCOLATE);
		                    } else {
		                    	setTextFill(Color.BLACK);
		                    }
		                }
					}
				};
			}
		});
		
		
		// Add data to the table
		personTable.setItems(personData);
	}
	
private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("EEE, d MMM yyyy", Locale.ENGLISH);

private String format(Calendar calendar) {
	return DATE_FORMAT.format(calendar.getTime());
}
}